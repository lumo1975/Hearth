const state = {
  items: [],
  categories: [],
  filter: { type: 'all', tags: [], exclusive: false },
  current: null
};
let media = null;
let lastVolume = 1;
let muted = false;
let modalItem = null;

const $ = (s) => document.querySelector(s);
const grid = $('#grid'), empty = $('#empty'), nav = $('#nav');
const fmt = (t) => {
  if (!t || isNaN(t)) return '0:00';
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return m + ':' + String(s).padStart(2, '0');
};
const escapeHtml = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const save = () => window.api.saveLibrary({ items: state.items, categories: state.categories });

// ---- Load / migrate ---------------------------------------------------
async function init() {
  const data = await window.api.loadLibrary();
  if (Array.isArray(data)) { state.items = data; state.categories = []; }
  else { state.items = data.items || []; state.categories = data.categories || []; }
  state.items.forEach((i) => { if (!Array.isArray(i.tags)) i.tags = []; });
  applyFilters();
}

// ---- Add / delete -----------------------------------------------------
$('#addBtn').onclick = async () => {
  const picked = await window.api.pickFiles();
  if (!picked.length) return;
  const known = new Set(state.items.map((i) => i.url));
  const fresh = picked.filter((p) => !known.has(p.url));
  fresh.forEach((f) => { if (!Array.isArray(f.tags)) f.tags = []; });
  state.items.push(...fresh);
  render();
  await Promise.all(fresh.filter((i) => i.type === 'video').map(async (i) => {
    i.thumb = await makeThumb(i.url);
  }));
  save();
  render();
};

function deleteItem(id) {
  state.items = state.items.filter((i) => i.id !== id);
  save();
  render();
}

function restart(it) {
  it.progress = 0;
  save();
  open(it);
}

// ---- Filter model (shared by sidebar + sort panel) --------------------
function setType(t) { state.filter.type = t; applyFilters(); }
function toggleTag(cat) {
  const tags = state.filter.tags;
  const i = tags.indexOf(cat);
  if (i >= 0) tags.splice(i, 1); else tags.push(cat);
  applyFilters();
}
function setExclusive(v) { state.filter.exclusive = v; applyFilters(); }
function clearFilters() { state.filter = { type: 'all', tags: [], exclusive: false }; applyFilters(); }

function matches(it) {
  const f = state.filter;
  if (f.type !== 'all' && it.type !== f.type) return false;
  if (f.tags.length) {
    return f.exclusive
      ? f.tags.every((t) => it.tags.includes(t))
      : f.tags.some((t) => it.tags.includes(t));
  }
  return true;
}

function applyFilters() {
  renderSidebar();
  renderSortPanel();
  render();
}

// ---- Sidebar ----------------------------------------------------------
nav.onclick = (e) => {
  const b = e.target.closest('.navbtn');
  if (b) setType(b.dataset.filter);
};

function renderSidebar() {
  [...nav.children].forEach((b) => {
    b.classList.toggle('active', state.filter.type === b.dataset.filter);
  });
  const cl = $('#catList');
  cl.innerHTML = '';
  state.categories.forEach((cat) => {
    const row = document.createElement('div');
    row.className = 'catrow';
    const b = document.createElement('button');
    b.className = 'catbtn' + (state.filter.tags.includes(cat) ? ' active' : '');
    b.innerHTML = `<span class="dot"></span><span class="cname">${escapeHtml(cat)}</span>`;
    b.onclick = () => toggleTag(cat);
    const x = document.createElement('button');
    x.className = 'catx';
    x.title = 'Delete category';
    x.textContent = '×';
    x.onclick = (e) => { e.stopPropagation(); deleteCategory(cat); };
    row.append(b, x);
    cl.appendChild(row);
  });
}

function deleteCategory(cat) {
  state.categories = state.categories.filter((c) => c !== cat);
  state.items.forEach((i) => { i.tags = i.tags.filter((t) => t !== cat); });
  state.filter.tags = state.filter.tags.filter((t) => t !== cat);
  save();
  applyFilters();
}

$('#newCat').onclick = () => {
  const w = $('#catInputWrap');
  w.hidden = !w.hidden;
  if (!w.hidden) $('#catInput').focus();
};
$('#catInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const name = $('#catInput').value.trim();
    if (name && !state.categories.includes(name)) state.categories.push(name);
    $('#catInput').value = '';
    $('#catInputWrap').hidden = true;
    save();
    renderSidebar();
    renderSortPanel();
  } else if (e.key === 'Escape') {
    $('#catInput').value = '';
    $('#catInputWrap').hidden = true;
  }
});

// ---- Sort panel -------------------------------------------------------
const sortPop = $('#sortPop'), sortBtn = $('#sortBtn');
sortBtn.onclick = (e) => { e.stopPropagation(); sortPop.hidden = !sortPop.hidden; };
document.addEventListener('click', (e) => {
  if (!sortPop.hidden && !sortPop.contains(e.target) && e.target !== sortBtn && !sortBtn.contains(e.target)) {
    sortPop.hidden = true;
  }
});
$('#typeSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) setType(b.dataset.type); };
$('#exclToggle').onclick = () => setExclusive(!state.filter.exclusive);
$('#clearFilters').onclick = clearFilters;

function renderSortPanel() {
  [...$('#typeSeg').children].forEach((b) => b.classList.toggle('on', b.dataset.type === state.filter.type));
  const wrap = $('#sortChips');
  wrap.innerHTML = '';
  if (!state.categories.length) {
    wrap.innerHTML = '<div class="muted">No categories yet.</div>';
  } else {
    state.categories.forEach((cat) => {
      const chip = document.createElement('button');
      chip.className = 'chip' + (state.filter.tags.includes(cat) ? ' on' : '');
      chip.textContent = cat;
      chip.onclick = () => toggleTag(cat);
      wrap.appendChild(chip);
    });
  }
  const sw = $('#exclToggle');
  sw.classList.toggle('on', state.filter.exclusive);
  sw.setAttribute('aria-checked', String(state.filter.exclusive));
}

// ---- Library grid -----------------------------------------------------
function tileTags(it) {
  const tags = it.tags || [];
  if (!tags.length) return '';
  const shown = tags.slice(0, 2).map((t) => `<span class="tchip">${escapeHtml(t)}</span>`).join('');
  const extra = tags.length > 2 ? `<span class="tchip more">+${tags.length - 2}</span>` : '';
  return `<div class="ttags">${shown}${extra}</div>`;
}

const ICON = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
  tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4l-7.2 7.2a2 2 0 01-2.8 0l-6.2-6.2A2 2 0 014 13V5.4A1.4 1.4 0 015.4 4H13a2 2 0 011.4.6l6.2 6.2a2 2 0 010 2.6z"/><circle cx="8" cy="8" r="1.2" fill="currentColor" stroke="none"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/></svg>',
  restart: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h2v14H7zM20 5l-9 7 9 7z"/></svg>'
};

function render() {
  const f = state.filter;
  $('#h').textContent = { all: 'My Media', video: 'My Videos', audio: 'My Audio' }[f.type];
  const list = state.items.filter(matches);

  let sub = state.items.length ? `${list.length} item${list.length === 1 ? '' : 's'}` : 'Nothing here yet';
  if (f.tags.length) sub += ` · ${f.exclusive ? 'all of' : 'any of'}: ${f.tags.join(', ')}`;
  $('#count').textContent = sub;
  empty.style.display = state.items.length ? 'none' : 'grid';

  grid.innerHTML = '';
  if (state.items.length && !list.length) {
    grid.innerHTML = '<div class="note">No files match this filter. Adjust the categories or clear the filter from the Sort panel.</div>';
    return;
  }

  list.forEach((it, idx) => {
    const resumable = it.progress > 0;
    const label = resumable ? 'Continue' : (it.type === 'video' ? 'Watch' : 'Listen');
    const tools =
      `<span class="tools">
         <span class="tbtn tag" title="Edit categories">${ICON.tag}</span>
         ${resumable ? `<span class="tbtn restart" title="Restart from beginning">${ICON.restart}</span>` : ''}
         <span class="tbtn del" title="Delete">${ICON.trash}</span>
       </span>`;
    const action = `<span class="action">${ICON.play}<span>${label}</span></span>`;
    const resume = (resumable && it.duration)
      ? `<span class="resume" style="width:${Math.min(100, it.progress / it.duration * 100).toFixed(1)}%"></span>`
      : '';

    const tile = document.createElement('button');
    tile.className = 'tile';
    if (it.type === 'video') {
      const hasThumb = !!it.thumb;
      tile.innerHTML =
        `<div class="thumb video${hasThumb ? ' has-thumb' : ''}"${hasThumb ? ` style="background-image:url('${it.thumb}')"` : ''}>
           ${tools}<span class="kind">Video</span>${action}${resume}
         </div>
         <div class="meta"><div class="t-title">${escapeHtml(it.name)}</div><div class="t-note">Video</div>${tileTags(it)}</div>`;
    } else {
      tile.innerHTML =
        `<div class="thumb audio">${tools}<span class="kind">Music</span><span class="disc"></span>${action}${resume}</div>
         <div class="meta"><div class="t-title">${escapeHtml(it.name)}</div><div class="t-note">Audio track</div>${tileTags(it)}</div>`;
    }
    tile.onclick = () => open(it);
    tile.querySelector('.del').onclick = (e) => { e.stopPropagation(); deleteItem(it.id); };
    tile.querySelector('.tag').onclick = (e) => { e.stopPropagation(); openTags(it); };
    const rb = tile.querySelector('.restart');
    if (rb) rb.onclick = (e) => { e.stopPropagation(); restart(it); };
    grid.appendChild(tile);
    requestAnimationFrame(() => setTimeout(() => tile.classList.add('in'), idx * 55));
  });
}

// ---- Category editor (modal) -----------------------------------------
function openTags(item) {
  modalItem = item;
  $('#mSub').textContent = item.name;
  renderChips();
  $('#modal').hidden = false;
  $('#mInput').value = '';
  $('#mInput').focus();
}
function renderChips() {
  const wrap = $('#mChips');
  wrap.innerHTML = '';
  if (!state.categories.length) {
    wrap.innerHTML = '<div class="muted">No categories yet. Create one below.</div>';
    return;
  }
  state.categories.forEach((cat) => {
    const on = modalItem.tags.includes(cat);
    const chip = document.createElement('button');
    chip.className = 'chip' + (on ? ' on' : '');
    chip.textContent = cat;
    chip.onclick = () => {
      if (on) modalItem.tags = modalItem.tags.filter((t) => t !== cat);
      else modalItem.tags.push(cat);
      save();
      renderChips();
      render();
    };
    wrap.appendChild(chip);
  });
}
function addCategoryFromModal() {
  const name = $('#mInput').value.trim();
  if (!name) return;
  if (!state.categories.includes(name)) state.categories.push(name);
  if (!modalItem.tags.includes(name)) modalItem.tags.push(name);
  $('#mInput').value = '';
  save();
  renderChips();
  renderSidebar();
  renderSortPanel();
  render();
}
$('#mAdd').onclick = addCategoryFromModal;
$('#mInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addCategoryFromModal(); });
$('#mClose').onclick = () => { $('#modal').hidden = true; modalItem = null; };
$('#modal').onclick = (e) => { if (e.target.id === 'modal') { $('#modal').hidden = true; modalItem = null; } };

// ---- Thumbnails -------------------------------------------------------
function makeThumb(url) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.src = url;
    const done = (val) => { v.removeAttribute('src'); v.load(); resolve(val); };
    v.addEventListener('loadeddata', () => {
      try { v.currentTime = Math.min(2, (v.duration || 4) * 0.25); } catch { done(null); }
    });
    v.addEventListener('seeked', () => {
      try {
        const w = 320, h = Math.round(w * (v.videoHeight / v.videoWidth)) || 180;
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        c.getContext('2d').drawImage(v, 0, 0, w, h);
        done(c.toDataURL('image/jpeg', 0.72));
      } catch { done(null); }
    });
    v.addEventListener('error', () => done(null));
  });
}

// ---- Player -----------------------------------------------------------
const stage = $('#stage'), fill = $('#fill'), track = $('#track');
const fsBtn = $('#fs'), volSlider = $('#volume'), muteBtn = $('#mute');

function open(it) {
  state.current = it;
  stage.innerHTML = '';
  if (it.type === 'video') {
    media = document.createElement('video');
    media.src = it.url;
    media.onclick = () => (media.paused ? media.play() : media.pause());
    stage.appendChild(media);
    fsBtn.hidden = false;
  } else {
    const wrap = document.createElement('div');
    wrap.className = 'listening';
    wrap.innerHTML = `<div class="bigdisc" id="bd"></div>
      <div class="np-title">${escapeHtml(it.name)}</div>
      <div class="eq" id="eq"><span></span><span></span><span></span><span></span><span></span></div>`;
    stage.appendChild(wrap);
    media = document.createElement('audio');
    media.src = it.url;
    stage.appendChild(media);
    fsBtn.hidden = true;
  }
  media.volume = muted ? 0 : lastVolume;
  volSlider.value = lastVolume;
  updateVolIcon();
  wire(it);
  $('#player').classList.add('show');
  media.play().then(setPlayIcon).catch(() => {});
}

function wire(it) {
  media.addEventListener('loadedmetadata', () => {
    it.duration = media.duration;
    if (it.progress && it.progress < media.duration - 2) media.currentTime = it.progress;
  });
  media.addEventListener('timeupdate', () => {
    fill.style.width = (media.currentTime / media.duration * 100 || 0) + '%';
    $('#cur').textContent = fmt(media.currentTime);
    $('#dur').textContent = fmt(media.duration);
  });
  media.addEventListener('play', () => { toggleSpin(true); setPlayIcon(); });
  media.addEventListener('pause', () => { toggleSpin(false); setPlayIcon(); saveProgress(it); });
  media.addEventListener('ended', () => { toggleSpin(false); setPlayIcon(); it.progress = 0; save(); });
}

function saveProgress(it) {
  if (media && media.currentTime) { it.progress = media.currentTime; save(); }
}
function toggleSpin(on) {
  const bd = $('#bd'), eq = $('#eq');
  if (bd) bd.classList.toggle('spin', on);
  if (eq) eq.classList.toggle('on', on);
}
function setPlayIcon() {
  $('#ppi').innerHTML = media && !media.paused
    ? '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>'
    : '<path d="M8 5v14l11-7z"/>';
}

function updateVolIcon() {
  const v = muted ? 0 : lastVolume;
  const wave = v === 0
    ? '<path d="M16 9l4 6M20 9l-4 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
    : v < 0.5
      ? '<path d="M16 9a4 4 0 010 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
      : '<path d="M16 8a5 5 0 010 8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>';
  $('#volicon').innerHTML = '<path d="M4 9v6h4l5 5V4L8 9H4z"/>' + wave;
}
volSlider.oninput = () => {
  lastVolume = parseFloat(volSlider.value);
  muted = lastVolume === 0;
  if (media) media.volume = lastVolume;
  updateVolIcon();
};
muteBtn.onclick = () => {
  muted = !muted;
  if (media) media.volume = muted ? 0 : lastVolume;
  volSlider.value = muted ? 0 : lastVolume;
  updateVolIcon();
};
fsBtn.onclick = () => { if (media && media.requestFullscreen) media.requestFullscreen(); };

$('#pp').onclick = () => { if (media) media.paused ? media.play() : media.pause(); };
track.onclick = (e) => {
  if (!media || !media.duration) return;
  const r = track.getBoundingClientRect();
  media.currentTime = (e.clientX - r.left) / r.width * media.duration;
};
$('#back').onclick = () => {
  if (media) { saveProgress(state.current); media.pause(); media.removeAttribute('src'); media.load(); media = null; }
  $('#player').classList.remove('show');
  render(); // reflect updated progress on the tiles
};

init();
