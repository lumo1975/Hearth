const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const url = require('url');

// Where the saved library lives (a per-user app data folder the OS gives us).
const libraryPath = () => path.join(app.getPath('userData'), 'library.json');

const VIDEO = new Set(['.mp4', '.mkv', '.mov', '.webm', '.avi', '.m4v']);
const AUDIO = new Set(['.mp3', '.m4a', '.aac', '.wav', '.flac', '.ogg', '.opus']);

function createWindow() {
  const win = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#191320',
    title: 'Hearth',
    icon: path.join(__dirname, process.platform === 'win32' ? 'build/icon.ico' : 'build/icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null); // removes the File/Edit/View/Window/Help bar
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Turn a file path into a library item, or null if it isn't a media file.
function toItem(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const type = VIDEO.has(ext) ? 'video' : AUDIO.has(ext) ? 'audio' : null;
  if (!type) return null;
  return {
    id: Math.random().toString(36).slice(2) + Date.now().toString(36),
    name: path.basename(filePath, path.extname(filePath)),
    type,
    url: url.pathToFileURL(filePath).href, // a file:// URL the player can load
    progress: 0,
    tags: []
  };
}

// Open the native "choose files" dialog and return media items.
ipcMain.handle('library:pick', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    title: 'Add media',
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Media', extensions: ['mp4', 'mkv', 'mov', 'webm', 'avi', 'm4v', 'mp3', 'm4a', 'aac', 'wav', 'flac', 'ogg', 'opus'] }
    ]
  });
  if (canceled) return [];
  return filePaths.map(toItem).filter(Boolean);
});

ipcMain.handle('library:load', async () => {
  try {
    return JSON.parse(fs.readFileSync(libraryPath(), 'utf-8'));
  } catch {
    return []; // no library yet
  }
});

ipcMain.handle('library:save', async (_event, items) => {
  try {
    fs.writeFileSync(libraryPath(), JSON.stringify(items, null, 2));
    return true;
  } catch {
    return false;
  }
});
