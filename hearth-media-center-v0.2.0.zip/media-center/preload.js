const { contextBridge, ipcRenderer } = require('electron');

// The only things the UI is allowed to ask the main process to do.
contextBridge.exposeInMainWorld('api', {
  pickFiles: () => ipcRenderer.invoke('library:pick'),
  loadLibrary: () => ipcRenderer.invoke('library:load'),
  saveLibrary: (items) => ipcRenderer.invoke('library:save', items)
});
