// Discord Rich Presence — connects to the local Discord desktop client over IPC.
//
// SETUP: paste your Application (Client) ID below. Under Rich Presence → Art
// Assets in the Discord Developer Portal, upload images named "hearth" (large,
// 1024x1024), "play", and "pause" (small). Then run `npm install` so the
// discord-rpc dependency is present.
const CLIENT_ID = '1547349633456537722';

let RPC = null;
try { RPC = require('discord-rpc'); } catch { RPC = null; } // dependency is optional; app runs without it

let client = null;
let ready = false;
let connecting = false;
let pending = null;

// status: 'unavailable' (dependency missing) | 'idle' | 'connecting' | 'connected' | 'no-discord'
let status = RPC ? 'idle' : 'unavailable';

function configured() { return !!RPC && CLIENT_ID && CLIENT_ID !== 'YOUR_DISCORD_APP_ID'; }
function getStatus() { return status; }

function connect() {
  if (!configured() || client || connecting) return;
  connecting = true;
  status = 'connecting';
  const c = new RPC.Client({ transport: 'ipc' });
  c.on('ready', () => {
    client = c; ready = true; connecting = false; status = 'connected';
    if (pending) sendActivity(pending);
  });
  c.on('disconnected', () => { client = null; ready = false; status = 'idle'; });
  // Rejects if Discord isn't running.
  c.login({ clientId: CLIENT_ID }).catch(() => { connecting = false; ready = false; client = null; status = 'no-discord'; });
}

// Force a connection attempt even before anything plays (so the toggle can verify reachability).
function enable() { if (configured()) connect(); }

// Build the RPC activity payload (snake_case, with a type) from the renderer's object.
function activityPayload(a) {
  const p = { type: a.type, instance: !!a.instance };
  if (a.details) p.details = a.details;
  if (a.state) p.state = a.state;
  const ts = {};
  if (a.startTimestamp) ts.start = a.startTimestamp;
  if (a.endTimestamp) ts.end = a.endTimestamp;
  if (ts.start || ts.end) p.timestamps = ts;
  const assets = {};
  if (a.largeImageKey) assets.large_image = a.largeImageKey;
  if (a.largeImageText) assets.large_text = a.largeImageText;
  if (a.smallImageKey) assets.small_image = a.smallImageKey;
  if (a.smallImageText) assets.small_text = a.smallImageText;
  if (Object.keys(assets).length) p.assets = assets;
  return p;
}

// The library's setActivity() can't send a type, so send it raw to get the
// Watching/Listening verb; if Discord rejects the type, fall back to the library.
function sendActivity(a) {
  if (typeof client.request === 'function' && a.type) {
    client.request('SET_ACTIVITY', { pid: process.pid, activity: activityPayload(a) })
      .catch(() => { client.setActivity(a).catch(() => {}); });
  } else {
    client.setActivity(a).catch(() => {});
  }
}

// activity = a Discord activity object, or null to clear.
function update(activity) {
  pending = activity || null;
  if (!configured()) return;
  if (!activity) { if (client && ready) client.clearActivity().catch(() => {}); return; }
  if (client && ready) sendActivity(activity);
  else connect();
}

function disable() {
  pending = null;
  if (client) {
    try { client.clearActivity().catch(() => {}); client.destroy().catch(() => {}); } catch { /* ignore */ }
  }
  client = null; ready = false; connecting = false;
  status = configured() ? 'idle' : 'unavailable';
}

module.exports = { update, disable, enable, getStatus };
