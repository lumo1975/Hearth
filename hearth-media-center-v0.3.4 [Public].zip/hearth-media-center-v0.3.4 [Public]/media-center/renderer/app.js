const state = {
  items: [],
  categories: [],
  playlists: [],
  filter: { type: 'all', tags: [], exclusive: false },
  screen: 'library',            // 'library' | 'jukebox' | 'theatre'
  sel: { audio: 'all', video: 'all' },    // selected playlist per mode ('all' | id)
  browseTags: { audio: [], video: [] },   // tag filter per mode (any-of)
  queue: [], queueSource: [], queueIndex: -1, queueActive: false, shuffle: false, repeat: 'off',
  queueName: '',
  settings: { richPresence: false },
  current: null
};
let media = null;
let lastVolume = 1;
let muted = false;
let modalItem = null;
let plModalItem = null;

const $ = (s) => document.querySelector(s);
const grid = $('#grid'), empty = $('#empty'), nav = $('#nav');
const fmt = (t) => {
  if (!t || isNaN(t)) return '0:00';
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return m + ':' + String(s).padStart(2, '0');
};
const escapeHtml = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

const save = () => window.api.saveLibrary({ items: state.items, categories: state.categories, playlists: state.playlists, settings: state.settings });

// ---- Load / migrate ---------------------------------------------------
async function init() {
  const data = await window.api.loadLibrary();
  if (Array.isArray(data)) { state.items = data; state.categories = []; state.playlists = []; }
  else {
    state.items = data.items || [];
    state.categories = data.categories || [];
    state.playlists = data.playlists || [];
  }
  state.items.forEach((i) => { if (!Array.isArray(i.tags)) i.tags = []; });
  state.playlists.forEach((p) => { if (!p.kind) p.kind = 'audio'; if (!Array.isArray(p.trackIds)) p.trackIds = []; });
  state.settings = Object.assign({ richPresence: false }, (!Array.isArray(data) && data.settings) || {});
  renderSettings();
  applyPresenceSetting();
  setScreen('library');
}

// ---- Add / delete -----------------------------------------------------
$('#addBtn').onclick = async () => {
  const picked = await window.api.pickFiles();
  if (!picked.length) return;
  const known = new Set(state.items.map((i) => i.url));
  const fresh = picked.filter((p) => !known.has(p.url));
  fresh.forEach((f) => { if (!Array.isArray(f.tags)) f.tags = []; });
  state.items.push(...fresh);
  render();
  await Promise.all(fresh.filter((i) => i.type === 'video').map(async (i) => {
    i.thumb = await makeThumb(i.url);
  }));
  save();
  render();
};

function deleteItem(id) {
  state.items = state.items.filter((i) => i.id !== id);
  state.playlists.forEach((p) => { p.trackIds = p.trackIds.filter((t) => t !== id); });
  save();
  render();
}

function restart(it) { it.progress = 0; save(); open(it, { resume: false }); }

// ---- Screen switching -------------------------------------------------
function setScreen(s) {
  state.screen = s;
  const browse = s === 'jukebox' || s === 'theatre';
  $('#library').hidden = s !== 'library';
  $('#jukebox').hidden = !browse;
  $('#catsSection').hidden = s !== 'library';
  $('#playlistsSection').hidden = !browse;
  renderSidebar();
  if (s === 'library') { renderSortPanel(); render(); }
  else {
    const m = mode();
    $('#plHead').textContent = m.head;
    $('#plInput').placeholder = m.ph;
    renderBrowseSidebar();
    renderBrowse();
  }
}

// ---- Grid filter model ------------------------------------------------
function setType(t) { state.filter.type = t; applyFilters(); }
function toggleTag(cat) {
  const tags = state.filter.tags;
  const i = tags.indexOf(cat);
  if (i >= 0) tags.splice(i, 1); else tags.push(cat);
  applyFilters();
}
function setExclusive(v) { state.filter.exclusive = v; applyFilters(); }
function clearFilters() { state.filter = { type: 'all', tags: [], exclusive: false }; applyFilters(); }

function matches(it) {
  const f = state.filter;
  if (f.type !== 'all' && it.type !== f.type) return false;
  if (f.tags.length) {
    return f.exclusive ? f.tags.every((t) => it.tags.includes(t)) : f.tags.some((t) => it.tags.includes(t));
  }
  return true;
}
function applyFilters() { renderSidebar(); renderSortPanel(); render(); }

// ---- Sidebar ----------------------------------------------------------
nav.onclick = (e) => {
  const b = e.target.closest('.navbtn');
  if (b && b.dataset.screen) setScreen(b.dataset.screen);
};

function renderSidebar() {
  [...nav.children].forEach((b) => {
    b.classList.toggle('active', state.screen === b.dataset.screen);
  });
  // Categories list (library sidebar)
  const cl = $('#catList');
  cl.innerHTML = '';
  state.categories.forEach((cat) => {
    const row = document.createElement('div');
    row.className = 'catrow';
    const b = document.createElement('button');
    b.className = 'catbtn' + (state.filter.tags.includes(cat) ? ' active' : '');
    b.innerHTML = `<span class="dot"></span><span class="cname">${escapeHtml(cat)}</span>`;
    b.onclick = () => toggleTag(cat);
    const x = document.createElement('button');
    x.className = 'catx'; x.title = 'Delete category'; x.textContent = '×';
    x.onclick = (e) => { e.stopPropagation(); deleteCategory(cat); };
    row.append(b, x);
    cl.appendChild(row);
  });
}

function deleteCategory(cat) {
  state.categories = state.categories.filter((c) => c !== cat);
  state.items.forEach((i) => { i.tags = i.tags.filter((t) => t !== cat); });
  state.filter.tags = state.filter.tags.filter((t) => t !== cat);
  state.browseTags.audio = state.browseTags.audio.filter((t) => t !== cat);
  state.browseTags.video = state.browseTags.video.filter((t) => t !== cat);
  save();
  applyFilters();
}

$('#newCat').onclick = () => {
  const w = $('#catInputWrap'); w.hidden = !w.hidden;
  if (!w.hidden) $('#catInput').focus();
};
$('#catInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const name = $('#catInput').value.trim();
    if (name && !state.categories.includes(name)) state.categories.push(name);
    $('#catInput').value = ''; $('#catInputWrap').hidden = true;
    save(); renderSidebar(); renderSortPanel();
  } else if (e.key === 'Escape') { $('#catInput').value = ''; $('#catInputWrap').hidden = true; }
});

// ---- Sort panel -------------------------------------------------------
const sortPop = $('#sortPop'), sortBtn = $('#sortBtn');
sortBtn.onclick = (e) => { e.stopPropagation(); sortPop.hidden = !sortPop.hidden; };
document.addEventListener('click', (e) => {
  if (!sortPop.hidden && !sortPop.contains(e.target) && e.target !== sortBtn && !sortBtn.contains(e.target)) sortPop.hidden = true;
});
$('#typeSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) setType(b.dataset.type); };
$('#exclToggle').onclick = () => setExclusive(!state.filter.exclusive);
$('#clearFilters').onclick = clearFilters;

function renderSortPanel() {
  [...$('#typeSeg').children].forEach((b) => b.classList.toggle('on', b.dataset.type === state.filter.type));
  const wrap = $('#sortChips'); wrap.innerHTML = '';
  if (!state.categories.length) wrap.innerHTML = '<div class="muted">No categories yet.</div>';
  else state.categories.forEach((cat) => {
    const chip = document.createElement('button');
    chip.className = 'chip' + (state.filter.tags.includes(cat) ? ' on' : '');
    chip.textContent = cat; chip.onclick = () => toggleTag(cat);
    wrap.appendChild(chip);
  });
  const sw = $('#exclToggle');
  sw.classList.toggle('on', state.filter.exclusive);
  sw.setAttribute('aria-checked', String(state.filter.exclusive));
}

// ---- Library grid -----------------------------------------------------
function tileTags(it) {
  const tags = it.tags || [];
  if (!tags.length) return '';
  const shown = tags.slice(0, 2).map((t) => `<span class="tchip">${escapeHtml(t)}</span>`).join('');
  const extra = tags.length > 2 ? `<span class="tchip more">+${tags.length - 2}</span>` : '';
  return `<div class="ttags">${shown}${extra}</div>`;
}

const ICON = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
  tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4l-7.2 7.2a2 2 0 01-2.8 0l-6.2-6.2A2 2 0 014 13V5.4A1.4 1.4 0 015.4 4H13a2 2 0 011.4.6l6.2 6.2a2 2 0 010 2.6z"/><circle cx="8" cy="8" r="1.2" fill="currentColor" stroke="none"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/></svg>',
  restart: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h2v14H7zM20 5l-9 7 9 7z"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
  film: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/></svg>'
};

function render() {
  const f = state.filter;
  $('#h').textContent = 'Library';
  const list = state.items.filter(matches);
  let sub = state.items.length ? `${list.length} item${list.length === 1 ? '' : 's'}` : 'Nothing here yet';
  const bits = [];
  if (f.type !== 'all') bits.push(f.type === 'video' ? 'videos' : 'audio');
  if (f.tags.length) bits.push(`${f.exclusive ? 'all of' : 'any of'}: ${f.tags.join(', ')}`);
  if (bits.length && state.items.length) sub += ' · ' + bits.join(' · ');
  $('#count').textContent = sub;
  empty.style.display = state.items.length ? 'none' : 'grid';

  grid.innerHTML = '';
  if (state.items.length && !list.length) {
    grid.innerHTML = '<div class="note">No files match this filter. Adjust the categories or clear the filter from the Sort panel.</div>';
    return;
  }
  list.forEach((it, idx) => {
    const resumable = it.progress > 0;
    const label = resumable ? 'Continue' : (it.type === 'video' ? 'Watch' : 'Listen');
    const tools =
      `<span class="tools">
         <span class="tbtn tag" title="Edit categories">${ICON.tag}</span>
         ${resumable ? `<span class="tbtn restart" title="Restart from beginning">${ICON.restart}</span>` : ''}
         <span class="tbtn del" title="Delete">${ICON.trash}</span>
       </span>`;
    const action = `<span class="action">${ICON.play}<span>${label}</span></span>`;
    const resume = (resumable && it.duration)
      ? `<span class="resume" style="width:${Math.min(100, it.progress / it.duration * 100).toFixed(1)}%"></span>` : '';
    const tile = document.createElement('button');
    tile.className = 'tile';
    if (it.type === 'video') {
      const hasThumb = !!it.thumb;
      tile.innerHTML =
        `<div class="thumb video${hasThumb ? ' has-thumb' : ''}"${hasThumb ? ` style="background-image:url('${it.thumb}')"` : ''}>
           ${tools}<span class="kind">Video</span>${action}${resume}
         </div>
         <div class="meta"><div class="t-title">${escapeHtml(it.name)}</div><div class="t-note">Video</div>${tileTags(it)}</div>`;
    } else {
      tile.innerHTML =
        `<div class="thumb audio">${tools}<span class="kind">Music</span><span class="disc"></span>${action}${resume}</div>
         <div class="meta"><div class="t-title">${escapeHtml(it.name)}</div><div class="t-note">Audio track</div>${tileTags(it)}</div>`;
    }
    tile.onclick = () => open(it, { resume: true });
    tile.querySelector('.del').onclick = (e) => { e.stopPropagation(); deleteItem(it.id); };
    tile.querySelector('.tag').onclick = (e) => { e.stopPropagation(); openTags(it); };
    const rb = tile.querySelector('.restart');
    if (rb) rb.onclick = (e) => { e.stopPropagation(); restart(it); };
    grid.appendChild(tile);
    requestAnimationFrame(() => setTimeout(() => tile.classList.add('in'), idx * 55));
  });
}

// ---- Jukebox / Theatre (shared "browse" screen) -----------------------
const byId = (id) => state.items.find((i) => i.id === id);

const MODE = {
  jukebox: { type: 'audio', all: 'All Audio', unit: 'track', head: 'Playlists', ph: 'Playlist name…',
             del: 'Delete playlist', pick: 'Add to playlist',
             emptyPl: 'This playlist is empty. Add tracks from All Audio with the + button.',
             emptyNone: 'No audio yet. Add some music from the library.',
             emptyTags: 'No audio matches these tags.' },
  theatre: { type: 'video', all: 'All Video', unit: 'video', head: 'Collections', ph: 'Collection name…',
             del: 'Delete collection', pick: 'Add to collection',
             emptyPl: 'This collection is empty. Add videos from All Video with the + button.',
             emptyNone: 'No video yet. Add some from the library.',
             emptyTags: 'No video matches these tags.' }
};
function mode() { return MODE[state.screen] || MODE.jukebox; }
function selId() { return state.sel[mode().type]; }

function currentPlaylist() {
  const id = selId();
  return id === 'all' ? null : state.playlists.find((p) => p.id === id);
}
function currentList() {
  const m = mode();
  const pl = currentPlaylist();
  if (pl) return pl.trackIds.map(byId).filter(Boolean);
  let list = state.items.filter((i) => i.type === m.type);
  const tags = state.browseTags[m.type];
  if (tags.length) list = list.filter((i) => tags.some((t) => i.tags.includes(t)));
  return list;
}

function renderBrowseSidebar() {
  const m = mode();
  const box = $('#plList'); box.innerHTML = '';
  const mk = (id, name, deletable) => {
    const row = document.createElement('div'); row.className = 'catrow';
    const b = document.createElement('button');
    b.className = 'catbtn' + (selId() === id ? ' active' : '');
    b.innerHTML = `<span class="dot"></span><span class="cname">${escapeHtml(name)}</span>`;
    b.onclick = () => { state.sel[m.type] = id; renderBrowseSidebar(); renderBrowse(); };
    row.appendChild(b);
    if (deletable) {
      const x = document.createElement('button');
      x.className = 'catx'; x.title = m.del; x.textContent = '×';
      x.onclick = (e) => { e.stopPropagation(); deletePlaylist(id); };
      row.appendChild(x);
    }
    box.appendChild(row);
  };
  mk('all', m.all, false);
  state.playlists.filter((p) => p.kind === m.type).forEach((p) => mk(p.id, p.name, true));
}

function createPlaylist(name, kind) {
  const p = { id: uid(), name, kind, trackIds: [] };
  state.playlists.push(p); save();
  return p;
}
function deletePlaylist(id) {
  const p = state.playlists.find((x) => x.id === id);
  state.playlists = state.playlists.filter((x) => x.id !== id);
  if (p && state.sel[p.kind] === id) state.sel[p.kind] = 'all';
  save(); renderBrowseSidebar(); renderBrowse();
}

$('#newPlaylist').onclick = () => {
  const w = $('#plInputWrap'); w.hidden = !w.hidden;
  if (!w.hidden) $('#plInput').focus();
};
$('#plInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const name = $('#plInput').value.trim();
    if (name) createPlaylist(name, mode().type);
    $('#plInput').value = ''; $('#plInputWrap').hidden = true;
    renderBrowseSidebar();
  } else if (e.key === 'Escape') { $('#plInput').value = ''; $('#plInputWrap').hidden = true; }
});

function renderBrowse() {
  const m = mode();
  const pl = currentPlaylist();
  $('#jbName').textContent = pl ? pl.name : m.all;
  $('#jbDelete').hidden = !pl;
  $('#jbDelete').textContent = m.del;
  $('#jbicon').innerHTML = m.type === 'video' ? ICON.film : ICON.note;

  // Tag filter only on the "All" view, scoped to categories this media type uses,
  // so audio genres and video genres never bleed into each other's filters.
  const usedCats = new Set();
  state.items.forEach((i) => { if (i.type === m.type) i.tags.forEach((t) => usedCats.add(t)); });
  state.browseTags[m.type] = state.browseTags[m.type].filter((t) => usedCats.has(t));
  const cats = state.categories.filter((c) => usedCats.has(c));

  const filterWrap = $('#jbFilter');
  if (!pl && cats.length) {
    filterWrap.hidden = false;
    filterWrap.innerHTML = '';
    cats.forEach((cat) => {
      const chip = document.createElement('button');
      chip.className = 'chip' + (state.browseTags[m.type].includes(cat) ? ' on' : '');
      chip.textContent = cat;
      chip.onclick = () => {
        const arr = state.browseTags[m.type];
        const i = arr.indexOf(cat);
        if (i >= 0) arr.splice(i, 1); else arr.push(cat);
        renderBrowse();
      };
      filterWrap.appendChild(chip);
    });
  } else { filterWrap.hidden = true; filterWrap.innerHTML = ''; }

  const list = currentList();
  $('#jbCount').textContent = list.length ? `${list.length} ${m.unit}${list.length === 1 ? '' : 's'}` : `No ${m.unit}s`;
  $('#jbPlay').disabled = !list.length;
  $('#jbShuffle').disabled = !list.length;

  const jbList = $('#jbList'), jbEmpty = $('#jbEmpty');
  jbList.innerHTML = '';
  if (!list.length) {
    jbEmpty.hidden = false;
    jbEmpty.textContent = pl ? m.emptyPl
      : (state.items.some((i) => i.type === m.type) ? m.emptyTags : m.emptyNone);
    return;
  }
  jbEmpty.hidden = true;

  list.forEach((it, idx) => {
    const playing = state.current === it && state.screen !== 'library';
    const row = document.createElement('div');
    row.className = 'trk' + (playing ? ' playing' : '');
    row.innerHTML =
      `<button class="trk-play" title="Play"><span class="idx">${idx + 1}</span>${ICON.play}</button>
       <div class="trk-main"><div class="trk-title">${escapeHtml(it.name)}</div>${tileTags(it)}</div>
       <div class="trk-dur">${it.duration ? fmt(it.duration) : '—'}</div>
       <button class="trk-btn add" title="${m.pick}">${ICON.plus}</button>
       ${pl ? `<button class="trk-btn rem" title="Remove">${ICON.trash}</button>` : ''}`;
    row.querySelector('.trk-play').onclick = () => playQueue(list, idx, false);
    row.querySelector('.trk-main').onclick = () => playQueue(list, idx, false);
    row.querySelector('.add').onclick = (e) => { e.stopPropagation(); openPlaylistPicker(it); };
    if (pl) row.querySelector('.rem').onclick = (e) => {
      e.stopPropagation();
      pl.trackIds = pl.trackIds.filter((t) => t !== it.id);
      save(); renderBrowse();
    };
    jbList.appendChild(row);
    if (!it.duration) ensureDuration(it, row.querySelector('.trk-dur'));
  });
}

$('#jbPlay').onclick = () => { const l = currentList(); if (l.length) playQueue(l, 0, false); };
$('#jbShuffle').onclick = () => { const l = currentList(); if (l.length) playQueue(l, 0, true); };
$('#jbDelete').onclick = () => { const pl = currentPlaylist(); if (pl) deletePlaylist(pl.id); };

// Read a file's duration once (video files via a video element), then cache + show it.
function ensureDuration(it, cell) {
  const el = document.createElement(it.type === 'video' ? 'video' : 'audio');
  el.preload = 'metadata'; el.src = it.url;
  el.addEventListener('loadedmetadata', () => {
    it.duration = el.duration; save();
    if (cell) cell.textContent = fmt(it.duration);
    el.removeAttribute('src'); el.load();
  });
  el.addEventListener('error', () => { el.removeAttribute('src'); });
}

// ---- Add-to-playlist / collection modal -------------------------------
function openPlaylistPicker(item) {
  plModalItem = item;
  const video = item.type === 'video';
  $('#plmTitle').textContent = video ? 'Add to collection' : 'Add to playlist';
  $('#plmInput').placeholder = video ? 'New collection…' : 'New playlist…';
  $('#plmSub').textContent = item.name;
  renderPlmChips();
  $('#plModal').hidden = false;
  $('#plmInput').value = ''; $('#plmInput').focus();
}
function renderPlmChips() {
  const wrap = $('#plmChips'); wrap.innerHTML = '';
  const lists = state.playlists.filter((p) => p.kind === plModalItem.type);
  if (!lists.length) { wrap.innerHTML = '<div class="muted">None yet. Create one below.</div>'; return; }
  lists.forEach((p) => {
    const on = p.trackIds.includes(plModalItem.id);
    const chip = document.createElement('button');
    chip.className = 'chip' + (on ? ' on' : '');
    chip.textContent = p.name;
    chip.onclick = () => {
      if (on) p.trackIds = p.trackIds.filter((t) => t !== plModalItem.id);
      else p.trackIds.push(plModalItem.id);
      save(); renderPlmChips();
      if (state.screen !== 'library') renderBrowse();
    };
    wrap.appendChild(chip);
  });
}
function addPlaylistFromModal() {
  const name = $('#plmInput').value.trim();
  if (!name) return;
  const p = createPlaylist(name, plModalItem.type);
  p.trackIds.push(plModalItem.id);
  $('#plmInput').value = '';
  save(); renderPlmChips(); if (state.screen !== 'library') renderBrowseSidebar();
}
$('#plmAdd').onclick = addPlaylistFromModal;
$('#plmInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addPlaylistFromModal(); });
$('#plmClose').onclick = () => { $('#plModal').hidden = true; plModalItem = null; };
$('#plModal').onclick = (e) => { if (e.target.id === 'plModal') { $('#plModal').hidden = true; plModalItem = null; } };

// ---- Queue playback ---------------------------------------------------
function shuffled(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function playQueue(list, index, shuffle) {
  state.queueName = currentPlaylist() ? currentPlaylist().name : mode().all;
  state.queueSource = list.slice();
  state.shuffle = shuffle;
  if (shuffle) {
    const first = list[index];
    const rest = shuffled(list.filter((_, i) => i !== index));
    state.queue = [first, ...rest];
    state.queueIndex = 0;
  } else {
    state.queue = list.slice();
    state.queueIndex = index;
  }
  state.queueActive = true;
  openCurrent();
}
function openCurrent() { open(state.queue[state.queueIndex], { resume: false, queue: true }); }
function playNext() {
  if (!state.queueActive) return;
  if (state.queueIndex < state.queue.length - 1) { state.queueIndex++; openCurrent(); }
  else if (state.repeat === 'all') { state.queueIndex = 0; openCurrent(); }
}
function playPrev() {
  if (!state.queueActive) return;
  if (media && media.currentTime > 3) { media.currentTime = 0; return; }
  if (state.queueIndex > 0) { state.queueIndex--; openCurrent(); }
  else if (media) media.currentTime = 0;
}
function toggleQueueShuffle() {
  if (!state.queueActive) return;
  const cur = state.queue[state.queueIndex];
  state.shuffle = !state.shuffle;
  if (state.shuffle) {
    const rest = shuffled(state.queueSource.filter((i) => i !== cur));
    state.queue = [cur, ...rest]; state.queueIndex = 0;
  } else {
    state.queue = state.queueSource.slice();
    state.queueIndex = Math.max(0, state.queue.indexOf(cur));
  }
  $('#shuf').classList.toggle('on', state.shuffle);
}
function cycleRepeat() {
  state.repeat = state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off';
  updateRepeatBtn();
}
function updateRepeatBtn() {
  repBtn.classList.toggle('on', state.repeat !== 'off');
  repBtn.title = state.repeat === 'off' ? 'Repeat off' : state.repeat === 'all' ? 'Repeat all' : 'Repeat one';
  const one = document.getElementById('repone');
  if (one) one.style.display = state.repeat === 'one' ? 'grid' : 'none';
}

// ---- Category editor modal -------------------------------------------
function openTags(item) {
  modalItem = item; $('#mSub').textContent = item.name;
  renderChips(); $('#modal').hidden = false; $('#mInput').value = ''; $('#mInput').focus();
}
function renderChips() {
  const wrap = $('#mChips'); wrap.innerHTML = '';
  if (!state.categories.length) { wrap.innerHTML = '<div class="muted">No categories yet. Create one below.</div>'; return; }
  state.categories.forEach((cat) => {
    const on = modalItem.tags.includes(cat);
    const chip = document.createElement('button');
    chip.className = 'chip' + (on ? ' on' : ''); chip.textContent = cat;
    chip.onclick = () => {
      if (on) modalItem.tags = modalItem.tags.filter((t) => t !== cat); else modalItem.tags.push(cat);
      save(); renderChips(); if (state.screen === 'library') render();
    };
    wrap.appendChild(chip);
  });
}
function addCategoryFromModal() {
  const name = $('#mInput').value.trim(); if (!name) return;
  if (!state.categories.includes(name)) state.categories.push(name);
  if (!modalItem.tags.includes(name)) modalItem.tags.push(name);
  $('#mInput').value = '';
  save(); renderChips(); renderSidebar(); renderSortPanel(); if (state.screen === 'library') render();
}
$('#mAdd').onclick = addCategoryFromModal;
$('#mInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addCategoryFromModal(); });
$('#mClose').onclick = () => { $('#modal').hidden = true; modalItem = null; };
$('#modal').onclick = (e) => { if (e.target.id === 'modal') { $('#modal').hidden = true; modalItem = null; } };

// ---- Thumbnails -------------------------------------------------------
// Pick a natural-looking poster: sample several frames across the middle of the
// video and keep the one with the most visual detail that isn't near-black or
// washed out — avoids intro cards, fades, and black first frames.
function makeThumb(url) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.src = url;
    let w = 320, h = 180;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const cleanup = (val) => { v.removeAttribute('src'); v.load(); resolve(val); };

    const seekTo = (t) => new Promise((res) => {
      let settled = false;
      const finish = () => { if (settled) return; settled = true; clearTimeout(timer); v.removeEventListener('seeked', finish); res(); };
      const timer = setTimeout(finish, 3000); // don't hang if a seek never lands
      v.addEventListener('seeked', finish);
      try { v.currentTime = t; } catch { finish(); }
    });

    // Higher is better: rewards detail (luma variance), penalizes dark / blown-out frames.
    const score = () => {
      let sum = 0, sumSq = 0, n = 0;
      try {
        const d = ctx.getImageData(0, 0, w, h).data;
        for (let i = 0; i < d.length; i += 16) {
          const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
          sum += lum; sumSq += lum * lum; n++;
        }
      } catch { return NaN; } // tainted / unreadable
      const mean = sum / n;
      const variance = sumSq / n - mean * mean;
      const penalty = mean < 20 ? 1e6 : mean > 235 ? 5e5 : 0; // near-black or washed out
      return variance - penalty;
    };

    v.addEventListener('loadeddata', async () => {
      const dur = v.duration;
      w = 320; h = Math.round(w * (v.videoHeight / v.videoWidth)) || 180;
      canvas.width = w; canvas.height = h;
      const fractions = (dur && isFinite(dur) && dur > 2) ? [0.2, 0.35, 0.5, 0.65, 0.8] : [0.5];
      let best = null, bestScore = -Infinity;
      for (const f of fractions) {
        await seekTo((dur || 2) * f);
        try { ctx.drawImage(v, 0, 0, w, h); } catch { continue; }
        const s = score();
        if (Number.isNaN(s)) { cleanup(null); return; } // can't read pixels; bail to play glyph
        if (s > bestScore) {
          bestScore = s;
          try { best = canvas.toDataURL('image/jpeg', 0.72); } catch { cleanup(null); return; }
        }
      }
      cleanup(best);
    });
    v.addEventListener('error', () => cleanup(null));
  });
}

// ---- Player -----------------------------------------------------------
const stage = $('#stage'), fill = $('#fill'), track = $('#track');
const fsBtn = $('#fs'), volSlider = $('#volume'), muteBtn = $('#mute');
const prevBtn = $('#prev'), nextBtn = $('#next'), shufBtn = $('#shuf'), repBtn = $('#rep');
const playerEl = $('#player');
const FS_ENTER = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 3H5a2 2 0 00-2 2v3M16 3h3a2 2 0 012 2v3M8 21H5a2 2 0 01-2-2v-3M16 21h3a2 2 0 002-2v-3"/></svg>';
const FS_EXIT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 3v3a2 2 0 01-2 2H3M16 3v3a2 2 0 002 2h3M8 21v-3a2 2 0 00-2-2H3M16 21v-3a2 2 0 012-2h3"/></svg>';

function open(it, opts = {}) {
  const queue = !!opts.queue;
  const resume = opts.resume !== false && !queue;
  if (!queue) { state.queueActive = false; state.queue = []; }
  state.current = it;
  stage.innerHTML = '';
  if (it.type === 'video') {
    media = document.createElement('video');
    media.src = it.url;
    media.onclick = () => (media.paused ? media.play() : media.pause());
    stage.appendChild(media);
    fsBtn.hidden = false;
  } else {
    const wrap = document.createElement('div');
    wrap.className = 'listening';
    wrap.innerHTML = `<div class="bigdisc" id="bd"></div>
      <div class="np-title">${escapeHtml(it.name)}</div>
      <div class="eq" id="eq"><span></span><span></span><span></span><span></span><span></span></div>`;
    stage.appendChild(wrap);
    media = document.createElement('audio');
    media.src = it.url;
    stage.appendChild(media);
    fsBtn.hidden = true;
  }
  // queue controls
  prevBtn.hidden = !queue; nextBtn.hidden = !queue; shufBtn.hidden = !queue; repBtn.hidden = !queue;
  shufBtn.classList.toggle('on', state.shuffle);
  updateRepeatBtn();

  media.volume = muted ? 0 : lastVolume;
  volSlider.value = lastVolume;
  updateVolIcon();
  wire(it, resume);
  $('#player').classList.add('show');
  media.play().then(setPlayIcon).catch(() => {});
  if (state.screen !== 'library') renderBrowse();
}

function wire(it, resume) {
  media.addEventListener('loadedmetadata', () => {
    it.duration = media.duration;
    if (resume && it.progress && it.progress < media.duration - 2) media.currentTime = it.progress;
    pushPresence(true);
  });
  media.addEventListener('timeupdate', () => {
    fill.style.width = (media.currentTime / media.duration * 100 || 0) + '%';
    $('#cur').textContent = fmt(media.currentTime);
    $('#dur').textContent = fmt(media.duration);
  });
  media.addEventListener('play', () => { toggleSpin(true); setPlayIcon(); pushPresence(true); });
  media.addEventListener('pause', () => { toggleSpin(false); setPlayIcon(); saveProgress(it); pushPresence(true); });
  media.addEventListener('ended', () => {
    toggleSpin(false); setPlayIcon(); it.progress = 0; save();
    if (state.repeat === 'one' && state.queueActive) { media.currentTime = 0; media.play().then(setPlayIcon).catch(() => {}); return; }
    if (state.queueActive) { playNext(); return; }
    pushPresence(true);
  });
}

function saveProgress(it) { if (media && media.currentTime) { it.progress = media.currentTime; save(); } }
function toggleSpin(on) {
  const bd = $('#bd'), eq = $('#eq');
  if (bd) bd.classList.toggle('spin', on);
  if (eq) eq.classList.toggle('on', on);
}
function setPlayIcon() {
  $('#ppi').innerHTML = media && !media.paused ? '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>';
}
function updateVolIcon() {
  const v = muted ? 0 : lastVolume;
  const wave = v === 0
    ? '<path d="M16 9l4 6M20 9l-4 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
    : v < 0.5
      ? '<path d="M16 9a4 4 0 010 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
      : '<path d="M16 8a5 5 0 010 8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>';
  $('#volicon').innerHTML = '<path d="M4 9v6h4l5 5V4L8 9H4z"/>' + wave;
}
volSlider.oninput = () => {
  lastVolume = parseFloat(volSlider.value); muted = lastVolume === 0;
  if (media) media.volume = lastVolume; updateVolIcon();
};
muteBtn.onclick = () => {
  muted = !muted; if (media) media.volume = muted ? 0 : lastVolume;
  volSlider.value = muted ? 0 : lastVolume; updateVolIcon();
};
let idleTimer = null;
function revealControls() {
  playerEl.classList.remove('idle');
  clearTimeout(idleTimer);
  if (document.fullscreenElement === playerEl) idleTimer = setTimeout(() => playerEl.classList.add('idle'), 2600);
}
playerEl.addEventListener('mousemove', revealControls);
fsBtn.onclick = () => {
  if (document.fullscreenElement) document.exitFullscreen();
  else if (playerEl.requestFullscreen) playerEl.requestFullscreen();
};
document.addEventListener('fullscreenchange', () => {
  const fs = document.fullscreenElement === playerEl;
  fsBtn.innerHTML = fs ? FS_EXIT : FS_ENTER;
  fsBtn.title = fs ? 'Exit fullscreen' : 'Fullscreen';
  if (fs) revealControls();
  else { clearTimeout(idleTimer); playerEl.classList.remove('idle'); }
});
prevBtn.onclick = playPrev;
nextBtn.onclick = playNext;
shufBtn.onclick = toggleQueueShuffle;
repBtn.onclick = cycleRepeat;

$('#pp').onclick = () => { if (media) media.paused ? media.play() : media.pause(); };
track.onclick = (e) => {
  if (!media || !media.duration) return;
  const r = track.getBoundingClientRect();
  media.currentTime = (e.clientX - r.left) / r.width * media.duration;
  pushPresence();
};
$('#back').onclick = () => {
  if (document.fullscreenElement) document.exitFullscreen();
  if (media) { saveProgress(state.current); media.pause(); media.removeAttribute('src'); media.load(); media = null; }
  $('#player').classList.remove('show');
  clearPresence();
  if (state.screen === 'library') render(); else renderBrowse();
};

// ---- Discord Rich Presence -------------------------------------------
let presenceTimer = null, lastPresence = 0;
function buildActivity() {
  if (!state.settings.richPresence || !media || media.ended || !state.current) return null;
  const it = state.current;
  const video = it.type === 'video';
  const a = {
    type: video ? 3 : 2,               // Watching : Listening (falls back to Playing if Discord rejects it)
    details: (it.name || 'Untitled').slice(0, 128),
    largeImageKey: 'hearth',
    largeImageText: 'Hearth',
    smallImageKey: media.paused ? 'pause' : 'play',
    smallImageText: media.paused ? 'Paused' : (video ? 'Watching' : 'Listening'),
    instance: false
  };
  if (state.queueActive && state.queueName) a.state = String(state.queueName).slice(0, 128);
  if (!media.paused && media.duration && isFinite(media.duration) && media.duration > 0) {
    // both ends → Discord draws a progress bar tied to the track's real position
    const now = Date.now();
    a.startTimestamp = now - Math.round(media.currentTime * 1000);
    a.endTimestamp = now + Math.round((media.duration - media.currentTime) * 1000);
  }
  return a;
}
function pushPresence(force) {
  if (!window.api || !window.api.updatePresence) return;   // preview / no bridge
  if (!state.settings.richPresence) return;                 // disabled — the toggle clears it
  const now = Date.now();
  clearTimeout(presenceTimer);
  const send = () => { lastPresence = Date.now(); window.api.updatePresence(buildActivity()); };
  if (force || now - lastPresence > 2000) send();           // stay under Discord's rate limit
  else presenceTimer = setTimeout(send, 2000 - (now - lastPresence));
}
function clearPresence() {
  clearTimeout(presenceTimer);
  if (window.api && window.api.updatePresence) window.api.updatePresence(null);
}
function applyPresenceSetting() {
  if (!window.api) return;
  if (state.settings.richPresence) {
    if (window.api.enablePresence) window.api.enablePresence(); // connect now, even if nothing is playing
    pushPresence(true);
  } else {
    clearTimeout(presenceTimer);
    if (window.api.disablePresence) window.api.disablePresence();
  }
}

// ---- Settings modal ---------------------------------------------------
let statusTimer = null;
function stopStatusPoll() { if (statusTimer) { clearInterval(statusTimer); statusTimer = null; } }
function startStatusPoll() { stopStatusPoll(); statusTimer = setInterval(refreshStatus, 1500); }
async function refreshStatus() {
  const el = $('#rpStatus');
  if (!el) return;
  el.className = 'setting-status';
  if (!state.settings.richPresence) { el.textContent = ''; return; }
  if (!window.api || !window.api.presenceStatus) { el.textContent = 'Rich Presence works only in the installed app, not this preview.'; return; }
  let s = 'idle';
  try { s = await window.api.presenceStatus(); } catch { s = 'idle'; }
  const info = {
    unavailable: ['warn', 'discord-rpc isn’t installed — run npm install, then rebuild.'],
    idle: ['', 'Waiting to connect…'],
    connecting: ['', 'Connecting to Discord…'],
    connected: ['ok', 'Connected to Discord. Play something to show it on your profile.'],
    'no-discord': ['warn', 'Discord desktop app not detected. Open Discord, then re-toggle.']
  };
  const [cls, msg] = info[s] || ['', ''];
  el.className = 'setting-status' + (cls ? ' ' + cls : '');
  el.textContent = msg;
}

$('#settingsBtn').onclick = () => { renderSettings(); $('#settingsModal').hidden = false; refreshStatus(); startStatusPoll(); };
$('#settingsClose').onclick = () => { $('#settingsModal').hidden = true; stopStatusPoll(); };
$('#settingsModal').onclick = (e) => { if (e.target.id === 'settingsModal') { $('#settingsModal').hidden = true; stopStatusPoll(); } };
$('#rpToggle').onclick = () => {
  state.settings.richPresence = !state.settings.richPresence;
  save();
  renderSettings();
  applyPresenceSetting();
  refreshStatus();
};
function renderSettings() {
  const on = state.settings.richPresence;
  const t = $('#rpToggle');
  t.classList.toggle('on', on);
  t.setAttribute('aria-checked', String(on));
}

init();
