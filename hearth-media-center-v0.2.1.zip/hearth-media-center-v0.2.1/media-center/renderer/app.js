const state = {
  items: [],
  categories: [],
  playlists: [],
  filter: { type: 'all', tags: [], exclusive: false },
  screen: 'library',            // 'library' | 'jukebox'
  jukeboxSel: 'all',            // 'all' | playlistId
  jukeboxTags: [],              // tag filter for All Audio (any-of)
  queue: [], queueSource: [], queueIndex: -1, queueActive: false, shuffle: false, repeat: 'off',
  current: null
};
let media = null;
let lastVolume = 1;
let muted = false;
let modalItem = null;
let plModalItem = null;

const $ = (s) => document.querySelector(s);
const grid = $('#grid'), empty = $('#empty'), nav = $('#nav');
const fmt = (t) => {
  if (!t || isNaN(t)) return '0:00';
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return m + ':' + String(s).padStart(2, '0');
};
const escapeHtml = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

const save = () => window.api.saveLibrary({ items: state.items, categories: state.categories, playlists: state.playlists });

// ---- Load / migrate ---------------------------------------------------
async function init() {
  const data = await window.api.loadLibrary();
  if (Array.isArray(data)) { state.items = data; state.categories = []; state.playlists = []; }
  else {
    state.items = data.items || [];
    state.categories = data.categories || [];
    state.playlists = data.playlists || [];
  }
  state.items.forEach((i) => { if (!Array.isArray(i.tags)) i.tags = []; });
  setScreen('library');
}

// ---- Add / delete -----------------------------------------------------
$('#addBtn').onclick = async () => {
  const picked = await window.api.pickFiles();
  if (!picked.length) return;
  const known = new Set(state.items.map((i) => i.url));
  const fresh = picked.filter((p) => !known.has(p.url));
  fresh.forEach((f) => { if (!Array.isArray(f.tags)) f.tags = []; });
  state.items.push(...fresh);
  render();
  await Promise.all(fresh.filter((i) => i.type === 'video').map(async (i) => {
    i.thumb = await makeThumb(i.url);
  }));
  save();
  render();
};

function deleteItem(id) {
  state.items = state.items.filter((i) => i.id !== id);
  state.playlists.forEach((p) => { p.trackIds = p.trackIds.filter((t) => t !== id); });
  save();
  render();
}

function restart(it) { it.progress = 0; save(); open(it, { resume: false }); }

// ---- Screen switching -------------------------------------------------
function setScreen(s) {
  state.screen = s;
  $('#library').hidden = s !== 'library';
  $('#jukebox').hidden = s !== 'jukebox';
  $('#catsSection').hidden = s !== 'library';
  $('#playlistsSection').hidden = s !== 'jukebox';
  renderSidebar();
  if (s === 'library') { renderSortPanel(); render(); }
  else { renderPlaylists(); renderJukebox(); }
}

// ---- Grid filter model ------------------------------------------------
function setType(t) { state.filter.type = t; applyFilters(); }
function toggleTag(cat) {
  const tags = state.filter.tags;
  const i = tags.indexOf(cat);
  if (i >= 0) tags.splice(i, 1); else tags.push(cat);
  applyFilters();
}
function setExclusive(v) { state.filter.exclusive = v; applyFilters(); }
function clearFilters() { state.filter = { type: 'all', tags: [], exclusive: false }; applyFilters(); }

function matches(it) {
  const f = state.filter;
  if (f.type !== 'all' && it.type !== f.type) return false;
  if (f.tags.length) {
    return f.exclusive ? f.tags.every((t) => it.tags.includes(t)) : f.tags.some((t) => it.tags.includes(t));
  }
  return true;
}
function applyFilters() { renderSidebar(); renderSortPanel(); render(); }

// ---- Sidebar ----------------------------------------------------------
nav.onclick = (e) => {
  const b = e.target.closest('.navbtn');
  if (!b) return;
  if (b.dataset.screen === 'jukebox') setScreen('jukebox');
  else { setScreen('library'); setType(b.dataset.filter); }
};

function renderSidebar() {
  [...nav.children].forEach((b) => {
    const active = b.dataset.screen === 'jukebox'
      ? state.screen === 'jukebox'
      : state.screen === 'library' && state.filter.type === b.dataset.filter;
    b.classList.toggle('active', active);
  });
  // Categories list (library sidebar)
  const cl = $('#catList');
  cl.innerHTML = '';
  state.categories.forEach((cat) => {
    const row = document.createElement('div');
    row.className = 'catrow';
    const b = document.createElement('button');
    b.className = 'catbtn' + (state.filter.tags.includes(cat) ? ' active' : '');
    b.innerHTML = `<span class="dot"></span><span class="cname">${escapeHtml(cat)}</span>`;
    b.onclick = () => toggleTag(cat);
    const x = document.createElement('button');
    x.className = 'catx'; x.title = 'Delete category'; x.textContent = '×';
    x.onclick = (e) => { e.stopPropagation(); deleteCategory(cat); };
    row.append(b, x);
    cl.appendChild(row);
  });
}

function deleteCategory(cat) {
  state.categories = state.categories.filter((c) => c !== cat);
  state.items.forEach((i) => { i.tags = i.tags.filter((t) => t !== cat); });
  state.filter.tags = state.filter.tags.filter((t) => t !== cat);
  state.jukeboxTags = state.jukeboxTags.filter((t) => t !== cat);
  save();
  applyFilters();
}

$('#newCat').onclick = () => {
  const w = $('#catInputWrap'); w.hidden = !w.hidden;
  if (!w.hidden) $('#catInput').focus();
};
$('#catInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const name = $('#catInput').value.trim();
    if (name && !state.categories.includes(name)) state.categories.push(name);
    $('#catInput').value = ''; $('#catInputWrap').hidden = true;
    save(); renderSidebar(); renderSortPanel();
  } else if (e.key === 'Escape') { $('#catInput').value = ''; $('#catInputWrap').hidden = true; }
});

// ---- Sort panel -------------------------------------------------------
const sortPop = $('#sortPop'), sortBtn = $('#sortBtn');
sortBtn.onclick = (e) => { e.stopPropagation(); sortPop.hidden = !sortPop.hidden; };
document.addEventListener('click', (e) => {
  if (!sortPop.hidden && !sortPop.contains(e.target) && e.target !== sortBtn && !sortBtn.contains(e.target)) sortPop.hidden = true;
});
$('#typeSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) setType(b.dataset.type); };
$('#exclToggle').onclick = () => setExclusive(!state.filter.exclusive);
$('#clearFilters').onclick = clearFilters;

function renderSortPanel() {
  [...$('#typeSeg').children].forEach((b) => b.classList.toggle('on', b.dataset.type === state.filter.type));
  const wrap = $('#sortChips'); wrap.innerHTML = '';
  if (!state.categories.length) wrap.innerHTML = '<div class="muted">No categories yet.</div>';
  else state.categories.forEach((cat) => {
    const chip = document.createElement('button');
    chip.className = 'chip' + (state.filter.tags.includes(cat) ? ' on' : '');
    chip.textContent = cat; chip.onclick = () => toggleTag(cat);
    wrap.appendChild(chip);
  });
  const sw = $('#exclToggle');
  sw.classList.toggle('on', state.filter.exclusive);
  sw.setAttribute('aria-checked', String(state.filter.exclusive));
}

// ---- Library grid -----------------------------------------------------
function tileTags(it) {
  const tags = it.tags || [];
  if (!tags.length) return '';
  const shown = tags.slice(0, 2).map((t) => `<span class="tchip">${escapeHtml(t)}</span>`).join('');
  const extra = tags.length > 2 ? `<span class="tchip more">+${tags.length - 2}</span>` : '';
  return `<div class="ttags">${shown}${extra}</div>`;
}

const ICON = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
  tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4l-7.2 7.2a2 2 0 01-2.8 0l-6.2-6.2A2 2 0 014 13V5.4A1.4 1.4 0 015.4 4H13a2 2 0 011.4.6l6.2 6.2a2 2 0 010 2.6z"/><circle cx="8" cy="8" r="1.2" fill="currentColor" stroke="none"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/></svg>',
  restart: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h2v14H7zM20 5l-9 7 9 7z"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>'
};

function render() {
  const f = state.filter;
  $('#h').textContent = { all: 'My Media', video: 'My Videos', audio: 'My Audio' }[f.type];
  const list = state.items.filter(matches);
  let sub = state.items.length ? `${list.length} item${list.length === 1 ? '' : 's'}` : 'Nothing here yet';
  if (f.tags.length) sub += ` · ${f.exclusive ? 'all of' : 'any of'}: ${f.tags.join(', ')}`;
  $('#count').textContent = sub;
  empty.style.display = state.items.length ? 'none' : 'grid';

  grid.innerHTML = '';
  if (state.items.length && !list.length) {
    grid.innerHTML = '<div class="note">No files match this filter. Adjust the categories or clear the filter from the Sort panel.</div>';
    return;
  }
  list.forEach((it, idx) => {
    const resumable = it.progress > 0;
    const label = resumable ? 'Continue' : (it.type === 'video' ? 'Watch' : 'Listen');
    const tools =
      `<span class="tools">
         <span class="tbtn tag" title="Edit categories">${ICON.tag}</span>
         ${resumable ? `<span class="tbtn restart" title="Restart from beginning">${ICON.restart}</span>` : ''}
         <span class="tbtn del" title="Delete">${ICON.trash}</span>
       </span>`;
    const action = `<span class="action">${ICON.play}<span>${label}</span></span>`;
    const resume = (resumable && it.duration)
      ? `<span class="resume" style="width:${Math.min(100, it.progress / it.duration * 100).toFixed(1)}%"></span>` : '';
    const tile = document.createElement('button');
    tile.className = 'tile';
    if (it.type === 'video') {
      const hasThumb = !!it.thumb;
      tile.innerHTML =
        `<div class="thumb video${hasThumb ? ' has-thumb' : ''}"${hasThumb ? ` style="background-image:url('${it.thumb}')"` : ''}>
           ${tools}<span class="kind">Video</span>${action}${resume}
         </div>
         <div class="meta"><div class="t-title">${escapeHtml(it.name)}</div><div class="t-note">Video</div>${tileTags(it)}</div>`;
    } else {
      tile.innerHTML =
        `<div class="thumb audio">${tools}<span class="kind">Music</span><span class="disc"></span>${action}${resume}</div>
         <div class="meta"><div class="t-title">${escapeHtml(it.name)}</div><div class="t-note">Audio track</div>${tileTags(it)}</div>`;
    }
    tile.onclick = () => open(it, { resume: true });
    tile.querySelector('.del').onclick = (e) => { e.stopPropagation(); deleteItem(it.id); };
    tile.querySelector('.tag').onclick = (e) => { e.stopPropagation(); openTags(it); };
    const rb = tile.querySelector('.restart');
    if (rb) rb.onclick = (e) => { e.stopPropagation(); restart(it); };
    grid.appendChild(tile);
    requestAnimationFrame(() => setTimeout(() => tile.classList.add('in'), idx * 55));
  });
}

// ---- Jukebox ----------------------------------------------------------
const byId = (id) => state.items.find((i) => i.id === id);

function currentPlaylist() {
  return state.jukeboxSel === 'all' ? null : state.playlists.find((p) => p.id === state.jukeboxSel);
}
function currentAudioList() {
  const pl = currentPlaylist();
  if (pl) return pl.trackIds.map(byId).filter(Boolean);
  let list = state.items.filter((i) => i.type === 'audio');
  if (state.jukeboxTags.length) list = list.filter((i) => state.jukeboxTags.some((t) => i.tags.includes(t)));
  return list;
}

function renderPlaylists() {
  const pl = $('#plList'); pl.innerHTML = '';
  const mk = (id, name, deletable) => {
    const row = document.createElement('div'); row.className = 'catrow';
    const b = document.createElement('button');
    b.className = 'catbtn' + (state.jukeboxSel === id ? ' active' : '');
    b.innerHTML = `<span class="dot"></span><span class="cname">${escapeHtml(name)}</span>`;
    b.onclick = () => { state.jukeboxSel = id; renderPlaylists(); renderJukebox(); };
    row.appendChild(b);
    if (deletable) {
      const x = document.createElement('button');
      x.className = 'catx'; x.title = 'Delete playlist'; x.textContent = '×';
      x.onclick = (e) => { e.stopPropagation(); deletePlaylist(id); };
      row.appendChild(x);
    }
    pl.appendChild(row);
  };
  mk('all', 'All Audio', false);
  state.playlists.forEach((p) => mk(p.id, p.name, true));
}

function createPlaylist(name) {
  const p = { id: uid(), name, trackIds: [] };
  state.playlists.push(p); save();
  return p;
}
function deletePlaylist(id) {
  state.playlists = state.playlists.filter((p) => p.id !== id);
  if (state.jukeboxSel === id) state.jukeboxSel = 'all';
  save(); renderPlaylists(); renderJukebox();
}

$('#newPlaylist').onclick = () => {
  const w = $('#plInputWrap'); w.hidden = !w.hidden;
  if (!w.hidden) $('#plInput').focus();
};
$('#plInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const name = $('#plInput').value.trim();
    if (name) createPlaylist(name);
    $('#plInput').value = ''; $('#plInputWrap').hidden = true;
    renderPlaylists();
  } else if (e.key === 'Escape') { $('#plInput').value = ''; $('#plInputWrap').hidden = true; }
});

function renderJukebox() {
  const pl = currentPlaylist();
  $('#jbName').textContent = pl ? pl.name : 'All Audio';
  $('#jbDelete').hidden = !pl;

  // Tag filter row only for All Audio
  const filterWrap = $('#jbFilter');
  if (!pl && state.categories.length) {
    filterWrap.hidden = false;
    filterWrap.innerHTML = '';
    state.categories.forEach((cat) => {
      const chip = document.createElement('button');
      chip.className = 'chip' + (state.jukeboxTags.includes(cat) ? ' on' : '');
      chip.textContent = cat;
      chip.onclick = () => {
        const i = state.jukeboxTags.indexOf(cat);
        if (i >= 0) state.jukeboxTags.splice(i, 1); else state.jukeboxTags.push(cat);
        renderJukebox();
      };
      filterWrap.appendChild(chip);
    });
  } else { filterWrap.hidden = true; filterWrap.innerHTML = ''; }

  const list = currentAudioList();
  $('#jbCount').textContent = list.length ? `${list.length} track${list.length === 1 ? '' : 's'}` : 'No tracks';
  $('#jbPlay').disabled = !list.length;
  $('#jbShuffle').disabled = !list.length;

  const jbList = $('#jbList'), jbEmpty = $('#jbEmpty');
  jbList.innerHTML = '';
  if (!list.length) {
    jbEmpty.hidden = false;
    jbEmpty.textContent = pl ? 'This playlist is empty. Add tracks from All Audio with the + button.'
      : (state.items.some((i) => i.type === 'audio') ? 'No audio matches these tags.' : 'No audio yet. Add some music from the library.');
    return;
  }
  jbEmpty.hidden = true;

  list.forEach((it, idx) => {
    const playing = state.current === it && state.screen === 'jukebox';
    const row = document.createElement('div');
    row.className = 'trk' + (playing ? ' playing' : '');
    row.innerHTML =
      `<button class="trk-play" title="Play"><span class="idx">${idx + 1}</span>${ICON.play}</button>
       <div class="trk-main"><div class="trk-title">${escapeHtml(it.name)}</div>${tileTags(it)}</div>
       <div class="trk-dur">${it.duration ? fmt(it.duration) : '—'}</div>
       <button class="trk-btn add" title="Add to playlist">${ICON.plus}</button>
       ${pl ? `<button class="trk-btn rem" title="Remove from playlist">${ICON.trash}</button>` : ''}`;
    row.querySelector('.trk-play').onclick = () => playQueue(list, idx, false);
    row.querySelector('.trk-main').onclick = () => playQueue(list, idx, false);
    row.querySelector('.add').onclick = (e) => { e.stopPropagation(); openPlaylistPicker(it); };
    if (pl) row.querySelector('.rem').onclick = (e) => {
      e.stopPropagation();
      pl.trackIds = pl.trackIds.filter((t) => t !== it.id);
      save(); renderJukebox();
    };
    jbList.appendChild(row);
    if (!it.duration) ensureDuration(it, row.querySelector('.trk-dur'));
  });
}

$('#jbPlay').onclick = () => { const l = currentAudioList(); if (l.length) playQueue(l, 0, false); };
$('#jbShuffle').onclick = () => { const l = currentAudioList(); if (l.length) playQueue(l, 0, true); };
$('#jbDelete').onclick = () => { const pl = currentPlaylist(); if (pl) deletePlaylist(pl.id); };

// Read an audio file's duration once, then cache + display it.
function ensureDuration(it, cell) {
  const a = document.createElement('audio');
  a.preload = 'metadata'; a.src = it.url;
  a.addEventListener('loadedmetadata', () => {
    it.duration = a.duration; save();
    if (cell) cell.textContent = fmt(it.duration);
    a.removeAttribute('src'); a.load();
  });
  a.addEventListener('error', () => { a.removeAttribute('src'); });
}

// ---- Playlist picker modal -------------------------------------------
function openPlaylistPicker(item) {
  plModalItem = item;
  $('#plmSub').textContent = item.name;
  renderPlmChips();
  $('#plModal').hidden = false;
  $('#plmInput').value = ''; $('#plmInput').focus();
}
function renderPlmChips() {
  const wrap = $('#plmChips'); wrap.innerHTML = '';
  if (!state.playlists.length) { wrap.innerHTML = '<div class="muted">No playlists yet. Create one below.</div>'; return; }
  state.playlists.forEach((p) => {
    const on = p.trackIds.includes(plModalItem.id);
    const chip = document.createElement('button');
    chip.className = 'chip' + (on ? ' on' : '');
    chip.textContent = p.name;
    chip.onclick = () => {
      if (on) p.trackIds = p.trackIds.filter((t) => t !== plModalItem.id);
      else p.trackIds.push(plModalItem.id);
      save(); renderPlmChips();
      if (state.screen === 'jukebox') renderJukebox();
    };
    wrap.appendChild(chip);
  });
}
function addPlaylistFromModal() {
  const name = $('#plmInput').value.trim();
  if (!name) return;
  const p = createPlaylist(name);
  p.trackIds.push(plModalItem.id);
  $('#plmInput').value = '';
  save(); renderPlmChips(); renderPlaylists();
}
$('#plmAdd').onclick = addPlaylistFromModal;
$('#plmInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addPlaylistFromModal(); });
$('#plmClose').onclick = () => { $('#plModal').hidden = true; plModalItem = null; };
$('#plModal').onclick = (e) => { if (e.target.id === 'plModal') { $('#plModal').hidden = true; plModalItem = null; } };

// ---- Queue playback ---------------------------------------------------
function shuffled(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function playQueue(list, index, shuffle) {
  state.queueSource = list.slice();
  state.shuffle = shuffle;
  if (shuffle) {
    const first = list[index];
    const rest = shuffled(list.filter((_, i) => i !== index));
    state.queue = [first, ...rest];
    state.queueIndex = 0;
  } else {
    state.queue = list.slice();
    state.queueIndex = index;
  }
  state.queueActive = true;
  openCurrent();
}
function openCurrent() { open(state.queue[state.queueIndex], { resume: false, queue: true }); }
function playNext() {
  if (!state.queueActive) return;
  if (state.queueIndex < state.queue.length - 1) { state.queueIndex++; openCurrent(); }
  else if (state.repeat === 'all') { state.queueIndex = 0; openCurrent(); }
}
function playPrev() {
  if (!state.queueActive) return;
  if (media && media.currentTime > 3) { media.currentTime = 0; return; }
  if (state.queueIndex > 0) { state.queueIndex--; openCurrent(); }
  else if (media) media.currentTime = 0;
}
function toggleQueueShuffle() {
  if (!state.queueActive) return;
  const cur = state.queue[state.queueIndex];
  state.shuffle = !state.shuffle;
  if (state.shuffle) {
    const rest = shuffled(state.queueSource.filter((i) => i !== cur));
    state.queue = [cur, ...rest]; state.queueIndex = 0;
  } else {
    state.queue = state.queueSource.slice();
    state.queueIndex = Math.max(0, state.queue.indexOf(cur));
  }
  $('#shuf').classList.toggle('on', state.shuffle);
}
function cycleRepeat() {
  state.repeat = state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off';
  updateRepeatBtn();
}
function updateRepeatBtn() {
  repBtn.classList.toggle('on', state.repeat !== 'off');
  repBtn.title = state.repeat === 'off' ? 'Repeat off' : state.repeat === 'all' ? 'Repeat all' : 'Repeat one';
  const one = document.getElementById('repone');
  if (one) one.style.display = state.repeat === 'one' ? 'grid' : 'none';
}

// ---- Category editor modal -------------------------------------------
function openTags(item) {
  modalItem = item; $('#mSub').textContent = item.name;
  renderChips(); $('#modal').hidden = false; $('#mInput').value = ''; $('#mInput').focus();
}
function renderChips() {
  const wrap = $('#mChips'); wrap.innerHTML = '';
  if (!state.categories.length) { wrap.innerHTML = '<div class="muted">No categories yet. Create one below.</div>'; return; }
  state.categories.forEach((cat) => {
    const on = modalItem.tags.includes(cat);
    const chip = document.createElement('button');
    chip.className = 'chip' + (on ? ' on' : ''); chip.textContent = cat;
    chip.onclick = () => {
      if (on) modalItem.tags = modalItem.tags.filter((t) => t !== cat); else modalItem.tags.push(cat);
      save(); renderChips(); if (state.screen === 'library') render();
    };
    wrap.appendChild(chip);
  });
}
function addCategoryFromModal() {
  const name = $('#mInput').value.trim(); if (!name) return;
  if (!state.categories.includes(name)) state.categories.push(name);
  if (!modalItem.tags.includes(name)) modalItem.tags.push(name);
  $('#mInput').value = '';
  save(); renderChips(); renderSidebar(); renderSortPanel(); if (state.screen === 'library') render();
}
$('#mAdd').onclick = addCategoryFromModal;
$('#mInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addCategoryFromModal(); });
$('#mClose').onclick = () => { $('#modal').hidden = true; modalItem = null; };
$('#modal').onclick = (e) => { if (e.target.id === 'modal') { $('#modal').hidden = true; modalItem = null; } };

// ---- Thumbnails -------------------------------------------------------
// Pick a natural-looking poster: sample several frames across the middle of the
// video and keep the one with the most visual detail that isn't near-black or
// washed out — avoids intro cards, fades, and black first frames.
function makeThumb(url) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.src = url;
    let w = 320, h = 180;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const cleanup = (val) => { v.removeAttribute('src'); v.load(); resolve(val); };

    const seekTo = (t) => new Promise((res) => {
      let settled = false;
      const finish = () => { if (settled) return; settled = true; clearTimeout(timer); v.removeEventListener('seeked', finish); res(); };
      const timer = setTimeout(finish, 3000); // don't hang if a seek never lands
      v.addEventListener('seeked', finish);
      try { v.currentTime = t; } catch { finish(); }
    });

    // Higher is better: rewards detail (luma variance), penalizes dark / blown-out frames.
    const score = () => {
      let sum = 0, sumSq = 0, n = 0;
      try {
        const d = ctx.getImageData(0, 0, w, h).data;
        for (let i = 0; i < d.length; i += 16) {
          const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
          sum += lum; sumSq += lum * lum; n++;
        }
      } catch { return NaN; } // tainted / unreadable
      const mean = sum / n;
      const variance = sumSq / n - mean * mean;
      const penalty = mean < 20 ? 1e6 : mean > 235 ? 5e5 : 0; // near-black or washed out
      return variance - penalty;
    };

    v.addEventListener('loadeddata', async () => {
      const dur = v.duration;
      w = 320; h = Math.round(w * (v.videoHeight / v.videoWidth)) || 180;
      canvas.width = w; canvas.height = h;
      const fractions = (dur && isFinite(dur) && dur > 2) ? [0.2, 0.35, 0.5, 0.65, 0.8] : [0.5];
      let best = null, bestScore = -Infinity;
      for (const f of fractions) {
        await seekTo((dur || 2) * f);
        try { ctx.drawImage(v, 0, 0, w, h); } catch { continue; }
        const s = score();
        if (Number.isNaN(s)) { cleanup(null); return; } // can't read pixels; bail to play glyph
        if (s > bestScore) {
          bestScore = s;
          try { best = canvas.toDataURL('image/jpeg', 0.72); } catch { cleanup(null); return; }
        }
      }
      cleanup(best);
    });
    v.addEventListener('error', () => cleanup(null));
  });
}

// ---- Player -----------------------------------------------------------
const stage = $('#stage'), fill = $('#fill'), track = $('#track');
const fsBtn = $('#fs'), volSlider = $('#volume'), muteBtn = $('#mute');
const prevBtn = $('#prev'), nextBtn = $('#next'), shufBtn = $('#shuf'), repBtn = $('#rep');

function open(it, opts = {}) {
  const queue = !!opts.queue;
  const resume = opts.resume !== false && !queue;
  if (!queue) { state.queueActive = false; state.queue = []; }
  state.current = it;
  stage.innerHTML = '';
  if (it.type === 'video') {
    media = document.createElement('video');
    media.src = it.url;
    media.onclick = () => (media.paused ? media.play() : media.pause());
    stage.appendChild(media);
    fsBtn.hidden = false;
  } else {
    const wrap = document.createElement('div');
    wrap.className = 'listening';
    wrap.innerHTML = `<div class="bigdisc" id="bd"></div>
      <div class="np-title">${escapeHtml(it.name)}</div>
      <div class="eq" id="eq"><span></span><span></span><span></span><span></span><span></span></div>`;
    stage.appendChild(wrap);
    media = document.createElement('audio');
    media.src = it.url;
    stage.appendChild(media);
    fsBtn.hidden = true;
  }
  // queue controls
  prevBtn.hidden = !queue; nextBtn.hidden = !queue; shufBtn.hidden = !queue; repBtn.hidden = !queue;
  shufBtn.classList.toggle('on', state.shuffle);
  updateRepeatBtn();

  media.volume = muted ? 0 : lastVolume;
  volSlider.value = lastVolume;
  updateVolIcon();
  wire(it, resume);
  $('#player').classList.add('show');
  media.play().then(setPlayIcon).catch(() => {});
  if (state.screen === 'jukebox') renderJukebox();
}

function wire(it, resume) {
  media.addEventListener('loadedmetadata', () => {
    it.duration = media.duration;
    if (resume && it.progress && it.progress < media.duration - 2) media.currentTime = it.progress;
  });
  media.addEventListener('timeupdate', () => {
    fill.style.width = (media.currentTime / media.duration * 100 || 0) + '%';
    $('#cur').textContent = fmt(media.currentTime);
    $('#dur').textContent = fmt(media.duration);
  });
  media.addEventListener('play', () => { toggleSpin(true); setPlayIcon(); });
  media.addEventListener('pause', () => { toggleSpin(false); setPlayIcon(); saveProgress(it); });
  media.addEventListener('ended', () => {
    toggleSpin(false); setPlayIcon(); it.progress = 0; save();
    if (state.repeat === 'one' && state.queueActive) { media.currentTime = 0; media.play().then(setPlayIcon).catch(() => {}); return; }
    if (state.queueActive) playNext();
  });
}

function saveProgress(it) { if (media && media.currentTime) { it.progress = media.currentTime; save(); } }
function toggleSpin(on) {
  const bd = $('#bd'), eq = $('#eq');
  if (bd) bd.classList.toggle('spin', on);
  if (eq) eq.classList.toggle('on', on);
}
function setPlayIcon() {
  $('#ppi').innerHTML = media && !media.paused ? '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>';
}
function updateVolIcon() {
  const v = muted ? 0 : lastVolume;
  const wave = v === 0
    ? '<path d="M16 9l4 6M20 9l-4 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
    : v < 0.5
      ? '<path d="M16 9a4 4 0 010 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
      : '<path d="M16 8a5 5 0 010 8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>';
  $('#volicon').innerHTML = '<path d="M4 9v6h4l5 5V4L8 9H4z"/>' + wave;
}
volSlider.oninput = () => {
  lastVolume = parseFloat(volSlider.value); muted = lastVolume === 0;
  if (media) media.volume = lastVolume; updateVolIcon();
};
muteBtn.onclick = () => {
  muted = !muted; if (media) media.volume = muted ? 0 : lastVolume;
  volSlider.value = muted ? 0 : lastVolume; updateVolIcon();
};
fsBtn.onclick = () => { if (media && media.requestFullscreen) media.requestFullscreen(); };
prevBtn.onclick = playPrev;
nextBtn.onclick = playNext;
shufBtn.onclick = toggleQueueShuffle;
repBtn.onclick = cycleRepeat;

$('#pp').onclick = () => { if (media) media.paused ? media.play() : media.pause(); };
track.onclick = (e) => {
  if (!media || !media.duration) return;
  const r = track.getBoundingClientRect();
  media.currentTime = (e.clientX - r.left) / r.width * media.duration;
};
$('#back').onclick = () => {
  if (media) { saveProgress(state.current); media.pause(); media.removeAttribute('src'); media.load(); media = null; }
  $('#player').classList.remove('show');
  if (state.screen === 'library') render(); else renderJukebox();
};

init();
